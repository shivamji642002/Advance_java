package com.ducat.dao.impl;

import com.ducat.dao.StudentDao;
import com.ducat.dao.util.ConnectionProvider;

public class StudentDaoImpl implements StudentDao{

	@Override
	public int registerUser() {

		ConnectionProvider.getMySqlConnection();
		
		return 0;
	}

}