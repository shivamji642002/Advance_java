package com.ducat.dao;

public interface StudentDao {

	int registerUser();

}