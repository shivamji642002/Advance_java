package com.ducat;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.ducat.dao.StudentDao;
import com.ducat.dao.impl.StudentDaoImpl;
import com.ducat.dao.util.ConnectionProvider;

public class App {

	public static void main(String[] args) {

//		System.out.println("Hello World");
//		Connection mysqlCon=ConnectionProvider.getMySqlConnection();
////		ConnectionProvider.getPostgreConnection();
//		
//		try {
//			Statement st = mysqlCon.createStatement();
//			ResultSet rs = st.executeQuery("select version();");
//			
//			rs.next();
//			System.out.println(rs.getString(1));
//			st.close();
//			rs.close();
//			mysqlCon.close();
//			
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}
		
		StudentDao dao=new StudentDaoImpl();
		int id=dao.registerUser();
		
	}
}