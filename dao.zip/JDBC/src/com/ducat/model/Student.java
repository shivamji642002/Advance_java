package com.ducat.model;

public class Student {

}
